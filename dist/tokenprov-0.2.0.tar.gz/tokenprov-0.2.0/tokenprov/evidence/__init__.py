from .repository import LocalEvidenceRepository
