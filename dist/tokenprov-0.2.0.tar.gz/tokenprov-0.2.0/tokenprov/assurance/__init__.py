from .deferred import DeferredWitnessRegistry

